import os

APP_PATH = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir))

PLUGIN_PATH = os.path.join(APP_PATH, "plugins/")
ROBOT_PATH = os.path.join(APP_PATH, "robot/")




