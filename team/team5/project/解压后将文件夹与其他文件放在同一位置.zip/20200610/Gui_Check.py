import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import random
import requests
from bs4 import BeautifulSoup
import threading
import pandas as pd
import datetime
import pandas as pd
import os
import webbrowser
from pyecharts import GeoLines, Style    #地理轨迹图的类就是Geolines

data = pd.read_excel('全国身份证号对应省市区.xls', header=None, names=['身份证前六位', '所属地区'])
gender_id = {'0': '女', '1': '男'}
class Window(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("疫情期间通行身份校验系统")
        self.layout = QGridLayout()
        self.setLayout(self.layout)  # 局部布局

        self.titleText = QTextBrowser()
        self.titleText.setText('疫情期间通行身份校验系统')
        self.titleText.setStyleSheet(
            "font-size:24px;font-weight:700;background-color: rgba(255,255,255,180);border: none;color:#0000CD")
         #   "font-size:24px;font-weight:700;background:white;background-color: rgba(255,255,255,255);border: none;color:#0000CD")
        self.titleText.setAlignment(Qt.AlignCenter)
        self.titleText.setFixedSize(500, 40)
        self.layout.addWidget(self.titleText, 0, 0, 1, 3 , Qt.AlignCenter)
        self.Text = QTextBrowser()
        self.Text.setText('请输入身份证号码：')
        self.Text.setAlignment(Qt.AlignRight)
        self.Text.setStyleSheet(
            "font-size:18px;font-weight:700;background-color: rgba(255,255,255,180);border: none;color:#0000CD")
        self.Text.setFixedSize(180, 30)
        self.layout.addWidget(self.Text, 1, 0, Qt.AlignRight)

        self.idcardText = QLineEdit(self)
        self.idcardText.setFixedSize(210, 30)
        self.idcardText.setStyleSheet("font-size:16px;font-weight:500;background-color: rgba(255,255,255,180);border: none;color:#55007f")
        self.layout.addWidget(self.idcardText, 1, 1, Qt.AlignLeft)

        self.Text = QTextBrowser()
        self.Text.setText('查询结果：')
        self.Text.setAlignment(Qt.AlignRight)
        self.Text.setStyleSheet(
            "font-size:18px;font-weight:700;background-color: rgba(255,255,255,180);border: none;color:#0000CD")
        self.Text.setFixedSize(105, 30)
        self.layout.addWidget(self.Text, 2, 0, Qt.AlignRight)

        self.resultText = QLineEdit(self)
        self.resultText.setFixedSize(210, 25)
        self.resultText.setStyleSheet(
            "font-size:16px;font-weight:500;background-color: rgba(255,255,255,180);border: none;color:#55007f")
        self.layout.addWidget(self.resultText, 2, 1, Qt.AlignLeft)

        self.Text = QTextBrowser()
        self.Text.setText('性别：')
        self.Text.setAlignment(Qt.AlignRight)
        self.Text.setStyleSheet(
            "font-size:18px;font-weight:700;background-color: rgba(255,255,255,180);border: none;color:#0000CD")
        self.Text.setFixedSize(65, 30)
        self.layout.addWidget(self.Text, 3, 0, Qt.AlignRight)

        self.genderText = QLineEdit(self)
        self.genderText.setFixedSize(210, 25)
        self.genderText.setStyleSheet(
            "font-size:16px;font-weight:500;background-color: rgba(255,255,255,180);border: none;color:#55007f")
        self.layout.addWidget(self.genderText, 3, 1, Qt.AlignLeft)

        self.Text = QTextBrowser()
        self.Text.setText('年龄：')
        self.Text.setAlignment(Qt.AlignRight)
        self.Text.setStyleSheet(
            "font-size:18px;font-weight:700;background-color: rgba(255,255,255,180);border: none;color:#0000CD")
        self.Text.setFixedSize(65, 30)
        self.layout.addWidget(self.Text, 4, 0, Qt.AlignRight)

        self.ageText = QLineEdit(self)
        self.ageText.setFixedSize(210, 25)
        self.ageText.setStyleSheet(
            "font-size:16px;font-weight:500;background-color: rgba(255,255,255,180);border: none;color:#55007f")
        self.layout.addWidget(self.ageText, 4, 1, Qt.AlignLeft)

        self.Text = QTextBrowser()
        self.Text.setText('发证地：')
        self.Text.setAlignment(Qt.AlignRight)
        self.Text.setStyleSheet(
            "font-size:18px;font-weight:700;background-color: rgba(255,255,255,180);border: none;color:#0000CD")
        self.Text.setFixedSize(85, 30)
        self.layout.addWidget(self.Text, 5, 0, Qt.AlignRight)

        self.addressText = QLineEdit(self)
        self.addressText.setFixedSize(210, 25)
        self.addressText.setStyleSheet(
            "font-size:16px;font-weight:500;background-color: rgba(255,255,255,180);border: none;color:#55007f")
        self.layout.addWidget(self.addressText, 5, 1, Qt.AlignLeft)

        self.startPushButton = QPushButton("开始查询")
        self.startPushButton.setFixedSize(70, 60)
        self.startPushButton.clicked.connect(self.check)
        self.layout.addWidget(self.startPushButton, 1, 2, 2, 2, Qt.AlignRight)
        

        self.startPushButton1 = QPushButton("查看路线")
        self.startPushButton1.setFixedSize(70, 60)
        self.startPushButton1.clicked.connect(self.route)
        self.layout.addWidget(self.startPushButton1, 3, 2, 2, 2, Qt.AlignRight)

    def check(self):
        idcard = self.idcardText.text()
        verification = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
        sum = 0
        for i, j in zip(list(idcard)[0:18], verification):
            sum += int(i) * j
        final_dic = {0: 1, 1: 0, 2: 'X', 3: 9, 4: 8, 5: 7, 6: 6, 7: 5, 8: 4, 9: 3, 10: 2}
        if str(final_dic[sum % 11]) == str(idcard[17]):
            self.resultText.setText('Successfull')
        else:
            self.resultText.setText('fail ')
        gender_id = {'0': '女', '1': '男'}
        gender = gender_id[str(int(idcard[16]) % 2)]
        age = int(datetime.datetime.now().year) - int(idcard[6:10])
        address = data[data['身份证前六位'].eq(idcard[:6])]['所属地区']

        self.genderText.setText(gender)
        self.ageText.setText(str(age))
        self.addressText.setText(str(address.values[0]))
    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'Message',
                                     "Are you sure to quit?", QMessageBox.Yes |
                                     QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()
    def route(self):
        url = "https://www.fastmock.site/mock/62e89c64391d93ce581798b816d8edec/smartbuild/base/python"
        
        res = requests.get(url)
        city = res
        print(city.text)

        idcard = self.idcardText.text()
        data1 = pd.read_excel('1.xlsx', header=None, names=['city', 'lad', 'long'])
        city = list(data1['city'])
        lad_list = list(data1['lad'])
        long_list = list(data1['long'])
        result = pd.DataFrame({'地点': city, '经度': lad_list, '纬度': long_list})

        geo_cities_coords = {result.iloc[i]['地点']: [result.iloc[i]['经度'], result.iloc[i]['纬度']]
                             for i in range(len(result))}
        # 设置画布的格式
        style = Style(title_pos="center",
                      width=1000,
                      height=800)

        # 部分地理轨迹图的格式
        style_geolines = style.add(is_label_show=True,
                                   line_curve=0.3,  # 轨迹线的弯曲度，0-1
                                   line_opacity=0.6,  # 轨迹线的透明度，0-1
                                   geo_effect_symbol='plane',  # 特效的图形，有circle,plane,pin等等
                                   geo_effect_symbolsize=10,  # 特效图形的大小
                                   geo_effect_color='#7FFFD4',  # 特效的颜色
                                   geo_effect_traillength=0.1,  # 特效图形的拖尾效果，0-1
                                   label_color=['#FFA500', '#FFF68F'],  # 轨迹线的颜色，标签点的颜色，
                                   border_color='#97FFFF',  # 边界的颜色
                                   geo_normal_color='#36648B',  # 地图的颜色
                                   label_formatter='{b}',  # 标签格式
                                   legend_pos='left')

        # 作图

        geolines = GeoLines('身份证号码为', idcard,  **style.init_style)
        geolines.add('从北京出发',
                     [('北京', '阿布扎比'), ('阿布扎比', '米兰'), ('米兰', '巴黎'), ('巴黎', '米兰')
                         , ('米兰', '阿布扎比'), ('阿布扎比', '北京'), ('北京', '郑州')],
                     maptype='world',
                     geo_cities_coords=geo_cities_coords,
                     **style_geolines)

        # 发布，得到图形的html文件
        geolines.render()
        webbrowser.open_new_tab('render.html')
        
app = QApplication(sys.argv)
show = Window()  #主窗口的类
palette = QPalette()
palette.setBrush(QPalette.Background, QBrush(QPixmap("微信图片2.png")))
show.setFixedSize(500, 250)
show.setPalette(palette)
show.show()
sys.exit(app.exec_())
