package com.example.socket2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

public class light extends AppCompatActivity {

    private TextView mTextView;
    TextView send_text;
    private String ipdress;
    private String portdress;
    Socket Socket = null;//Socket
    boolean RD = false;//用于控制读数据线程是否执行
    Button L1;

    String light1;

    java.io.OutputStream OutputStream = null;//定义数据输出流，用于发送数据
    java.io.InputStream InputStream = null;//定义数据输入流，用于接收数据

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.light);

        send_text = findViewById(R.id.text_send);
        mTextView = (TextView) findViewById(R.id.textView4);
        Intent intent = getIntent();
        light1 = intent.getStringExtra("test");
        ipdress = intent.getStringExtra("ip");
        portdress = intent.getStringExtra("port");
        mTextView.setText(light1);

        L1 = findViewById(R.id.L1);

        if (light1.equals("on")) {
            L1.setText("关");
        } else{
            L1.setText("开");
        }
    }

    public void open1(View view){

        if (L1.getText().equals("关"))
        {
            L1.setText("开");
            send_text.setText("1");
            mTextView.setText("off");
        }else {
            L1.setText("关");
            send_text.setText("0");
            mTextView.setText("on");
        }
        //如果按钮没有被按下，则按钮状态改为按下
        //读数据线程可以执行
        RD = true;
        //并创建一个新的线程，用于初始化socket
        light.Connect_Thread Connect_thread = new light.Connect_Thread();
        Connect_thread.start();
        //改变按钮标题
        //如果按钮已经被按下，则改变按钮标题


        try {
            Thread.currentThread().sleep(200);//阻断0.2秒
        } catch (InterruptedException e) {
            e.printStackTrace();
        }




        //验证编辑框用户输入内容是否合法
        if (thisif()) {
            //启动一个新的线程，用于发送数据
            ThreadSendData t1 = new ThreadSendData();
            t1.start();
        } else{
            //这个地方默认是没有反应，可以自行修改成信息框提示
            return;
        }
    }

    //用线程创建Socket连接
    class Connect_Thread extends Thread{
        public void run(){
            //定义一个变量用于储存ip
            InetAddress ipAddress;
            try {
                //判断socket的状态，防止重复执行
                if (Socket == null) {
                    //如果socket为空则执行
                    //获取输入的IP地址
                    ipAddress = InetAddress.getByName(ipdress);
                    //获取输入的端口
                    int port = Integer.valueOf(portdress);
                    //新建一个socket
                    Socket = new Socket(ipAddress, port);
                    //获取socket的输入流和输出流
                    InputStream = Socket.getInputStream();
                    OutputStream = Socket.getOutputStream();

                    //新建一个线程读数据
                    ThreadSendData t1 = new ThreadSendData();
                    t1.start();
                }
            } catch (Exception e) {
                //如果有错误则在这里返回
                e.printStackTrace();
            }
        }
    }

    //用线程发送数据
    class ThreadSendData extends Thread{
        public void run(){
            try {
                //用输出流发送数据
                OutputStream.write(send_text.getText().toString().getBytes());
                //发送数据之后会自动断开连接，所以，恢复为最初的状态
                //有个坑要说一下，因为发送完数据还得等待服务器返回，所以，不能把Socket也注销掉
                //改变按钮标题
                //  Button.setText("连 接 服 务 器");
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    //验证编辑框内容是否合法
    public boolean thisif (){
        //定义一个信息框留作备用
        AlertDialog.Builder message = new AlertDialog.Builder(this);
        message.setPositiveButton("确定",click1);

        //分别获取ip、端口、数据这三项的内容
        String ip = ipdress;
        String port = portdress;
        String data = send_text.getText().toString();

        //判断是否有编辑框为空
        if (ip == null || ip.length() == 0 || port == null || port.length() == 0 || data == null || data.length() == 0){
            //如果有空则弹出提示
            message.setMessage("各数据不能为空！");
            AlertDialog m1 = message.create();
            m1.show();
            return false;
        }else{
            return true;
        }
    }

    //信息框按钮按下事件
    public DialogInterface.OnClickListener click1 = new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            dialog.cancel();
        }
    };



}
