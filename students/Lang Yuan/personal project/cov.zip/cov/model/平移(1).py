import vtk

import pyaudio
import wave
from aip import AipSpeech
from xpinyin import Pinyin
import requests
#from weather import *
#from nature import *
#from music import *
import os
from os import system
import win32com.client

speaker = win32com.client.Dispatch("SAPI.SpVoice")
 

CHUNK = 1024
FORMAT = pyaudio.paInt16
CHANNELS = 2
RATE = 8000
RECORD_SECONDS = 5
WAVE_OUTPUT_FILENAME = "audio.wav"


APP_ID = '18980660'
API_KEY = 'hwoVnCcUV1VoizMZzHU7ayu6'
SECRET_KEY = 'Z1ynGkPNF1GBoYnnMPBdxt4lY8mm48QS'
client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)

STATE = 0
TIME_START = 0
TIME_END = 0

num_basketball = 10

class vtkTimerCallback1():
   def __init__(self):
       self.timer_count = 0
       self.actors=[]
   def execute(self,obj,event):
       print(self.timer_count)
       cnt=0
       for act in self.actors:
          if cnt%2==0:
             act.SetPosition(self.timer_count, 0,0);
          else:
             act.SetPosition(0, self.timer_count,0);
          cnt+=1
       iren = obj
       iren.GetRenderWindow().Render()
       self.timer_count += 1

    
def playVoice(fileName):
    os.system("madplay -v " + fileName)
 

def readFile(fileName):
    with open(fileName, 'rb') as fp:
        return fp.read()
    
def writeFile(fileName,result):
    with open(fileName, 'wb') as fp:
        fp.write(result)
        
def getBaiduText():
    p = pyaudio.PyAudio()

    stream = p.open(format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    frames_per_buffer=CHUNK)

    stream.start_stream()
    
    print("请随时说出暂停将暂停消毒？")
    speaker.Speak("请随时说出暂停将暂停消毒？")
    
    print("* 开始录音......")
    
    frames = []
    for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
        data = stream.read(CHUNK)
        frames.append(data)

    stream.stop_stream()
 
    wf = wave.open(WAVE_OUTPUT_FILENAME, 'wb')
    wf.setnchannels(CHANNELS)
    wf.setsampwidth(p.get_sample_size(FORMAT))
    wf.setframerate(RATE)
    wf.writeframes(b''.join(frames))
    
    print("正在识别......")
    result = client.asr(readFile('audio.wav'), 'wav', 16000, {
    'dev_pid': 1537,
})
    if result["err_no"] == 0:
        for t in result["result"]:
            return t
    else:
        print("没有识别到语音\n")
        return ""
      
def getBaiduVoice(text):
    result  = client.synthesis(text, 'zh', 6, {'vol': 5, 'per':4,'spd':5})
    if not isinstance(result, dict):
        writeFile("back.mp3",result)
    os.system("back.mp3")
    #playVoice("back.mp3")


def getVoiceResult():
    return baiduVoice()

def getPinYin(result):
    pin = Pinyin()
    return pin.get_pinyin(result)

def wakeUp(result,pinyin):

    if getPinYin("不用") in pinyin or getPinYin("谢谢") in pinyin or getPinYin("不需要") in pinyin :
        print("谢谢你的使用，感谢下次光临！")
        speaker.Speak("谢谢你的使用，感谢下次光临！")
        os._exit(0)
    else:
        print("无法识别，请重新操作")
        speaker.Speak("无法识别，请重新操作")
        



def main():

      #Read STL
      reader = vtk.vtkSTLReader()
##      reader1 = vtk.vtkSTLReader()
      reader.SetFileName("robot.stl")
##      reader1.SetFileName("robotx.stl")

     #Create a mapper and actor
      mapper = vtk.vtkPolyDataMapper()
      mapper.SetInputConnection(reader.GetOutputPort())
      actor = vtk.vtkActor()
      actor.SetMapper(mapper)
      prop = actor.GetProperty()
      

##      mapper1 = vtk.vtkPolyDataMapper()
##      mapper1.SetInputConnection(reader.GetOutputPort())
##      actor1 = vtk.vtkActor()
##      actor1.SetMapper(mapper1)


      # Setup a renderer, render window, and interactor
      renderer = vtk.vtkRenderer()
      renderWindow = vtk.vtkRenderWindow()
      renderWindow.AddRenderer(renderer);
      renderWindowInteractor = vtk.vtkRenderWindowInteractor()
      renderWindowInteractor.SetRenderWindow(renderWindow)

      #Add the actor to the scene
      renderer.AddActor(actor)
##      renderer.AddActor(actor1)
      renderer.SetBackground(1,1,1) # Background color white

      #Render and interact
      renderWindow.Render()

      # Initialize must be called prior to creating timer events.
      renderWindowInteractor.Initialize()

      # Sign up to receive TimerEvent
      cb = vtkTimerCallback1()
      cb.actors.append(actor)
##      cb.actors.append(actor1)
      renderWindowInteractor.AddObserver('TimerEvent', cb.execute)
      timerId = renderWindowInteractor.CreateRepeatingTimer(100);
      actor.RotateX(-270)
      actor.RotateY(180)
##      actor1.RotateX(-270)
##      actor1.RotateY(180)
      
      
      #start the interaction and timer
      renderWindowInteractor.Start()
      
      while True:
           result = getBaiduText()
           pinyin = getPinYin(result)
           print(result)
           wakeUp(result,pinyin)

        

if __name__ == '__main__':
   main()
